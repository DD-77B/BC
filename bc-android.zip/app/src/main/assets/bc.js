/* Переключатель приложений BC — плавающая кнопка, как в SWS.
   Свёрнута в одну полупрозрачную кнопку со значком текущего приложения; касание раскрывает список,
   кнопку можно перетащить к любому краю экрана (место запоминается). */
(function () {
  var p = location.pathname, cur = /\/kino\//.test(p) ? 'kino' : /\/books\//.test(p) ? 'books' : 'hub';
  var HUB = '/assets/index.html';
  var APPS = { books: { href: '/assets/books/index.html', label: 'Книги', emoji: '📚' }, kino: { href: '/assets/kino/index.html', label: 'Кино', emoji: '🍿' } };
  window.BC = { app: cur, apps: APPS, hub: function () { location.href = HUB + '?choose=1'; }, open: function (k) { try { localStorage.setItem('bc_last', k); } catch (e) {} location.href = APPS[k].href; } };
  if (cur === 'hub') return;
  try { localStorage.setItem('bc_last', cur); } catch (e) {}
  var KEY = 'bc_switch_pos';
  function loadPos() { try { var v = JSON.parse(localStorage.getItem(KEY) || 'null'); if (v && (v.s === 'l' || v.s === 'r') && v.y >= 0 && v.y <= 1) return v; } catch (e) {} return { s: 'l', y: 0.82 }; }
  var box, open;
  function mount() {
    if (document.getElementById('bc-app-switch')) return;
    var css = document.createElement('style');
    css.textContent =
      '#bc-app-switch{position:fixed;z-index:8000;width:46px;height:46px;touch-action:none;font:600 15px -apple-system,system-ui,sans-serif;transition:opacity .25s}' +
      '#bc-app-switch .bcfab{width:46px;height:46px;border-radius:50%;border:0;padding:0;display:grid;place-items:center;font-size:22px;line-height:1;cursor:pointer;' +
        'background:rgba(255,255,255,.72);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);box-shadow:0 4px 16px rgba(0,0,0,.18);color:#1d1d1f;transition:transform .15s}' +
      '#bc-app-switch.idle{opacity:.5}' +
      '#bc-app-switch.drag .bcfab{transform:scale(1.12)}' +
      '#bc-app-switch .menu{position:absolute;display:none;flex-direction:column;gap:6px;min-width:190px}' +
      '#bc-app-switch.open .menu{display:flex}' +
      '#bc-app-switch.open .bcfab{background:#1d1d1f;color:#fff}' +
      '#bc-app-switch .menu a{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:16px;text-decoration:none;color:#1d1d1f;white-space:nowrap;' +
        'background:rgba(255,255,255,.92);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);box-shadow:0 4px 14px rgba(0,0,0,.16)}' +
      '#bc-app-switch .menu a i{font-style:normal;font-size:20px;width:24px;display:grid;place-items:center}' +
      '#bc-app-switch .menu a.cur{opacity:.45;pointer-events:none}' +
      'html[data-theme=dark] #bc-app-switch .bcfab{background:rgba(44,44,46,.78);color:#f5f5f7}html[data-theme=dark] #bc-app-switch .menu a{background:rgba(44,44,46,.94);color:#f5f5f7}html[data-theme=dark] #bc-app-switch.open .bcfab{background:#f5f5f7;color:#1d1d1f}' +
      '#bc-app-switch.hid{display:none}';
    document.head.appendChild(css);
    box = document.createElement('div'); box.id = 'bc-app-switch'; box.className = 'idle';
    var items = '<a href="' + HUB + '?choose=1"><i>⌂</i>Все приложения</a>' + Object.keys(APPS).map(function (k) {
      return '<a href="' + APPS[k].href + '"' + (k === cur ? ' class="cur"' : '') + '><i>' + APPS[k].emoji + '</i>' + APPS[k].label + '</a>';
    }).join('');
    box.innerHTML = '<div class="menu" role="menu">' + items + '</div><button class="bcfab" aria-label="Приложения BC" aria-expanded="false">' + APPS[cur].emoji + '</button>';
    // вешаем на <html>, а не на <body>: масштаб «Крупнее» (zoom у body) не сдвигает кнопку
    document.documentElement.appendChild(box);
    setInterval(function () { box.classList.toggle('hid', !!document.querySelector('.modal.active,#readerScreen.active,#videoPlayer.active,#fabMenu.active')); }, 400);
    var fab = box.querySelector('.bcfab'), menu = box.querySelector('.menu'), pos = loadPos(), idleT = 0, closeT = 0;
    function place() {
      var H = window.innerHeight, W = window.innerWidth;
      var top = Math.max(8, Math.min(H - 54, pos.y * H - 23));
      box.style.top = top + 'px'; box.style.left = pos.s === 'l' ? '8px' : (W - 54) + 'px';
      var up = top > H / 2;
      menu.style.left = pos.s === 'l' ? '0' : ''; menu.style.right = pos.s === 'r' ? '0' : '';
      menu.style.bottom = up ? '54px' : ''; menu.style.top = up ? '' : '54px';
      menu.style.flexDirection = up ? 'column-reverse' : 'column';
    }
    function setIdle() { clearTimeout(idleT); box.classList.remove('idle'); idleT = setTimeout(function () { if (!box.classList.contains('open')) box.classList.add('idle'); }, 2500); }
    open = function (v) {
      box.classList.toggle('open', v); fab.setAttribute('aria-expanded', v);
      clearTimeout(closeT); if (v) { box.classList.remove('idle'); closeT = setTimeout(function () { open(false); }, 6000); } else setIdle();
    };
    place(); window.addEventListener('resize', place);
    var sx = 0, sy = 0, moved = false, dragging = false;
    fab.addEventListener('pointerdown', function (e) { dragging = true; moved = false; sx = e.clientX; sy = e.clientY; try { fab.setPointerCapture(e.pointerId); } catch (x) {} setIdle(); });
    fab.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      if (!moved && Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) < 8) return;
      if (!moved) { moved = true; open(false); box.classList.add('drag'); }
      box.style.left = Math.max(4, Math.min(window.innerWidth - 50, e.clientX - 23)) + 'px';
      box.style.top = Math.max(4, Math.min(window.innerHeight - 50, e.clientY - 23)) + 'px';
    });
    function end(e) {
      if (!dragging) return; dragging = false; box.classList.remove('drag');
      if (moved) {
        pos = { s: e.clientX < window.innerWidth / 2 ? 'l' : 'r', y: Math.max(0.05, Math.min(0.95, e.clientY / window.innerHeight)) };
        try { localStorage.setItem(KEY, JSON.stringify(pos)); } catch (x) {}
        place(); setIdle();
      } else open(!box.classList.contains('open'));
    }
    fab.addEventListener('pointerup', end); fab.addEventListener('pointercancel', end);
    document.addEventListener('pointerdown', function (e) { if (box.classList.contains('open') && !box.contains(e.target)) open(false); }, true);
    setIdle();
  }
  // «Назад» системы: закрыть меню → окна приложения → экран «Все приложения»
  function wrapBack() {
    var orig = window.androidBack;
    window.androidBack = function () {
      if (box && box.classList.contains('open')) { open(false); return true; }
      if (orig && orig()) return true;
      window.BC.hub(); return true;
    };
  }
  if (document.body) { mount(); wrapBack(); } else document.addEventListener('DOMContentLoaded', function () { mount(); wrapBack(); });
})();
