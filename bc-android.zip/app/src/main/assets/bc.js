/* BC — переключатель между «Книгами» и «Кино» внутри одного приложения */
(function () {
  var P = location.pathname, APP = P.indexOf('/kino/') >= 0 ? 'kino' : P.indexOf('/books/') >= 0 ? 'books' : 'hub';
  var APPS = { books: { n: 'Книги', e: '📚', u: '/assets/books/index.html', img: '/assets/img/books.png' }, kino: { n: 'Кино', e: '🎬', u: '/assets/kino/index.html', img: '/assets/img/kino.png' } };
  function hub() { try { sessionStorage.setItem('bc_nohop', '1'); } catch (e) {} location.href = '/assets/index.html'; }
  window.BC = { app: APP, apps: APPS, hub: hub, open: function (k) { location.href = APPS[k].u; } };
  if (APP === 'hub') return;
  try { localStorage.setItem('bc_last', APP); } catch (e) {}
  var css = document.createElement('style');
  css.textContent = '.bc-pop{position:fixed;inset:0;z-index:10000;background:rgba(0,0,0,.35);display:flex;align-items:flex-start;justify-content:center;padding-top:70px;opacity:0;transition:opacity .15s}.bc-pop.on{opacity:1}' +
    '.bc-box{width:min(92vw,360px);background:var(--card,#fff);color:var(--text,#000);border-radius:20px;padding:10px;box-shadow:0 12px 40px rgba(0,0,0,.25)}' +
    '.bc-it{display:flex;align-items:center;gap:14px;width:100%;border:0;background:none;color:inherit;font:inherit;font-size:17px;font-weight:600;padding:10px;border-radius:14px;cursor:pointer;text-align:left}' +
    '.bc-it img{width:44px;height:44px;border-radius:11px}.bc-it .bc-h{width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:22px;background:var(--bg,#F2F2F7)}' +
    '.header h1{white-space:nowrap;font-size:clamp(24px,7.5vw,32px)}.header-btns{gap:6px!important}.header-btns .layout-toggle,.header-btns .ai-key-btn{width:30px;height:30px}'+'.bc-it.cur{background:var(--bg,#F2F2F7)}.bc-it small{display:block;font-size:13px;font-weight:400;color:var(--text2,#8E8E93)}';
  document.head.appendChild(css);
  var pop = null;
  function close() { if (!pop) return false; var p = pop; pop = null; p.classList.remove('on'); setTimeout(function () { p.remove(); }, 150); return true; }
  function openPop() {
    if (pop) return close();
    pop = document.createElement('div'); pop.className = 'bc-pop';
    pop.innerHTML = '<div class="bc-box">' + Object.keys(APPS).map(function (k) { var a = APPS[k]; return '<button class="bc-it ' + (k === APP ? 'cur' : '') + '" data-k="' + k + '"><img src="' + a.img + '" alt=""><span>' + a.n + '<small>' + (k === APP ? 'открыто сейчас' : 'перейти') + '</small></span></button>'; }).join('') +
      '<button class="bc-it" data-k="hub"><span class="bc-h">⌂</span><span>Главная BC<small>оба приложения</small></span></button></div>';
    pop.onclick = function (e) { var b = e.target.closest('[data-k]'); if (!b) { close(); return; } var k = b.getAttribute('data-k'); close(); if (k === 'hub') hub(); else if (k !== APP) location.href = APPS[k].u; };
    document.body.appendChild(pop); requestAnimationFrame(function () { pop && pop.classList.add('on'); });
  }
  function addBtn() {
    var hb = document.querySelector('.header-btns'); if (!hb || document.getElementById('bcSwitch')) return;
    var b = document.createElement('button'); b.id = 'bcSwitch';
    b.className = hb.querySelector('.layout-toggle') ? 'layout-toggle' : 'ai-key-btn';
    b.title = 'Книги / Кино'; b.textContent = APP === 'kino' ? '📚' : '🎬'; b.style.fontSize = '17px';
    b.onclick = openPop; hb.insertBefore(b, hb.firstChild);
  }
  function wrapBack() {
    var orig = window.androidBack;
    window.androidBack = function () { if (close()) return true; if (orig && orig()) return true; hub(); return true; };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { addBtn(); wrapBack(); }); else { addBtn(); wrapBack(); }
})();
