/* BC: голосовой ввод — перенос механизма «Диктовщика» (v38) один в один:
   • запись целиком одним файлом (без нарезки), 48 кГц моно, 128 кбит/с, шумодав и автоусиление;
   • OpenAI whisper-1 или Groq whisper-large-v3, temperature 0, response_format text;
   • prompt как в Диктовщике: «Текст на русском языке. Литературный стиль…» + контекст;
     контекст = ваш текст из настроек + автоматически название и автор/режиссёр открытой карточки;
   • голосовые команды пунктуации («запятая», «новый абзац», «вопросительный знак»…), заглавные буквы;
   • ИИ-коррекция (gpt-4o-mini / llama-3.3-70b) с той же инструкцией, что в Диктовщике.
   Добавлено сверх Диктовщика: неудачная запись не теряется (кнопка «Повторить»), а очень длинная
   диктовка (>20 мин) сама продолжается вторым файлом, чтобы не упереться в лимит 25 МБ.
   BCVoice.attach(textarea, { context: function () { return '…'; } }) */
(function () {
  if (window.BCVoice) return;
  var SET = 'bc_voice2', GROQ = 'bc_groq_key', OAI = 'books_openai_api_key';
  var SEG_MS = 20 * 60 * 1000;
  var LANGS = [['ru', '🇷🇺 Рус'], ['en', '🇺🇸 Eng'], ['es', '🇪🇸 Esp'], ['uk', '🇺🇦 Укр'], ['de', '🇩🇪 Deu'], ['fr', '🇫🇷 Fra'], ['it', '🇮🇹 Ita']];
  var LANG_PREP = { en: 'английском', es: 'испанском', ru: 'русском', de: 'немецком', fr: 'французском', it: 'итальянском', uk: 'украинском' };
  var MIC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/></svg>';
  var STOP = '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2.2" fill="currentColor"/></svg>';

  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k) || ''; if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); } catch (e) { return ''; } }
  function cfg() {
    var d = { engine: '', lang: 'ru', ctx: '', correct: true };
    try { var s = JSON.parse(ls(SET) || '{}'); for (var k in s) d[k] = s[k]; } catch (e) {}
    if (!d.engine) d.engine = ls(OAI) ? 'openai' : (ls(GROQ) ? 'groq' : 'openai');
    return d;
  }
  function saveCfg(c) { ls(SET, JSON.stringify(c)); }
  function keyFor(engine) { return ls(engine === 'groq' ? GROQ : OAI).trim(); }
  function esc(t) { return String(t || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function buzz(ms) { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} }

  /* ---------- обработка текста — как в Диктовщике ---------- */
  var CMDS_BY_LANG = {
    en: {
      multi: [['question mark', '? '], ['exclamation mark', '! '], ['exclamation point', '! '], ['semicolon', '; '], ['new paragraph', '\n\n'], ['new line', '\n'],
        ['ellipsis', '... '], ['three dots', '... '], ['open quote', '“'], ['close quote', '”'], ['full stop', '. '], ['em dash', ' — ']],
      single: { 'comma': ', ', 'colon': ': ' },
      tail: /\s+period[.,!?]?\s*$/i
    },
    es: {
      multi: [['signo de interrogación', '? '], ['signo de exclamación', '! '], ['punto y coma', '; '], ['punto y aparte', '.\n\n'], ['punto y seguido', '. '], ['nuevo párrafo', '\n\n'],
        ['nueva línea', '\n'], ['puntos suspensivos', '... '], ['abrir comillas', '«'], ['cerrar comillas', '»'], ['dos puntos', ': ']],
      single: { 'coma': ', ' },
      tail: /\s+punto[.,!?]?\s*$/i
    }
  };
  function capitalizeSentences(t) {
    try { t = t.replace(new RegExp('([.!?…]\\s+|\\n)(\\p{Ll})', 'gu'), function (m, a, b) { return a + b.toUpperCase(); }); }
    catch (e) { t = t.replace(/([.!?]\s+)([а-яёa-z])/g, function (m, a, b) { return a + b.toUpperCase(); }); }
    if (t.length) t = t.charAt(0).toUpperCase() + t.slice(1);
    return t;
  }
  function processText(text, lc) {
    var t = text, extra = CMDS_BY_LANG[lc] || { multi: [], single: {}, tail: null };
    var multi = [['вопросительный знак', '? '], ['восклицательный знак', '! '], ['точка с запятой', '; '], ['новая строка', '\n'], ['новый абзац', '\n\n'],
      ['три точки', '... '], ['открыть кавычки', '«'], ['закрыть кавычки', '»']].concat(extra.multi);
    for (var i = 0; i < multi.length; i++) {
      var cmd = multi[i][0], rep = multi[i][1], low = t.toLowerCase(), idx = low.indexOf(cmd);
      while (idx !== -1) { t = t.substring(0, idx) + rep + t.substring(idx + cmd.length); low = t.toLowerCase(); idx = low.indexOf(cmd); }
    }
    var single = { 'запятая': ', ', 'кома': ', ', 'точка': '. ', 'тире': ' — ', 'двоеточие': ': ', 'кавычки': '"' };
    for (var k in extra.single) single[k] = extra.single[k];
    var words = t.split(' ');
    for (i = 0; i < words.length; i++) { var w = words[i].toLowerCase().replace(/[.,!?;:]+$/, ''); if (single[w]) words[i] = single[w]; }
    t = words.join(' ');
    if (extra.tail) t = t.replace(extra.tail, '. ');
    if (lc !== 'fr') t = t.replace(/[ \t]+([,.!?;:])/g, '$1');
    t = t.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]*\n[ \t]*/g, '\n');
    return capitalizeSentences(t.trim());
  }
  function whisperPrompt(lc, ctx) {
    var base = {
      ru: 'Текст на русском языке. Литературный стиль. Произношение пунктуации словами преобразовать в символы.',
      en: 'Text in English. Literary style. Spoken punctuation such as "comma" and "question mark" is converted to symbols.',
      es: 'Texto en español. Estilo literario. La puntuación dictada con palabras ("coma", "signo de interrogación") se convierte en símbolos.'
    }[lc] || 'Literary style text with correct punctuation.';
    if (!ctx) return base;
    return base + (lc === 'ru' ? ' Контекст: ' : lc === 'es' ? ' Contexto: ' : ' Context: ') + ctx;
  }

  /* ---------- распознавание и коррекция ---------- */
  function transcribe(blob, c, ctx) {
    var key = keyFor(c.engine);
    if (!key) return Promise.reject(new Error('Нет ключа ' + (c.engine === 'groq' ? 'Groq' : 'OpenAI')));
    if (c.engine === 'groq' && key.indexOf('gsk_') !== 0) return Promise.reject(new Error('Ключ Groq должен начинаться с gsk_'));
    var ext = /mp4|m4a|aac/.test(blob.type) ? 'm4a' : /ogg/.test(blob.type) ? 'ogg' : 'webm';
    var fd = new FormData();
    fd.append('file', blob, 'audio.' + ext);
    fd.append('model', c.engine === 'groq' ? 'whisper-large-v3' : 'whisper-1');
    fd.append('language', c.lang);
    fd.append('prompt', whisperPrompt(c.lang, ctx));
    fd.append('response_format', 'text');
    fd.append('temperature', '0');
    var url = c.engine === 'groq' ? 'https://api.groq.com/openai/v1/audio/transcriptions' : 'https://api.openai.com/v1/audio/transcriptions';
    return fetch(url, { method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: fd }).then(function (r) {
      return r.text().then(function (t) {
        if (!r.ok) {
          if (r.status === 401) throw new Error('Неверный ключ ' + (c.engine === 'groq' ? 'Groq' : 'OpenAI'));
          if (r.status === 429) throw new Error('Лимит запросов — попробуйте через минуту');
          var m = t; try { var j = JSON.parse(t); m = (j.error && (j.error.message || j.error)) || t; } catch (e) {}
          throw new Error('Ошибка ' + r.status + ': ' + String(m).slice(0, 120));
        }
        return String(t || '').trim();
      });
    });
  }
  function aiCorrect(text, c, ctx) {
    var key = keyFor(c.engine);
    var url = c.engine === 'groq' ? 'https://api.groq.com/openai/v1/chat/completions' : 'https://api.openai.com/v1/chat/completions';
    var model = c.engine === 'groq' ? 'llama-3.3-70b-versatile' : 'gpt-4o-mini';
    var sys = 'Ты корректор текста для диктовки на ' + (LANG_PREP[c.lang] || 'языке оригинала') + ' языке — это личный отзыв автора (мужчины) о книге или фильме. ' +
      'Исправь пунктуацию, регистр букв, опечатки и явные ошибки распознавания речи (в том числе искажённые имена, названия и фамилии — сверяйся с контекстом). ' +
      'НЕ меняй смысл, стиль и не сокращай текст. Верни только исправленный текст без комментариев.' + (ctx ? ' Контекст: ' + ctx : '');
    return fetch(url, {
      method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: model, messages: [{ role: 'system', content: sys }, { role: 'user', content: text }], temperature: 0.2 })
    }).then(function (r) { return r.json(); }).then(function (d) {
      var out = d && d.choices && d.choices[0] && d.choices[0].message ? String(d.choices[0].message.content || '').trim() : '';
      // защита: коррекция не должна резко укоротить или раздуть текст
      if (!out || out.length < text.length * 0.6 || out.length > text.length * 1.6 + 40) return text;
      return out;
    }).catch(function () { return text; });
  }

  /* ---------- стили ---------- */
  var css = document.createElement('style');
  css.textContent =
    '.bcv-mic{flex-shrink:0;width:44px;height:44px;border-radius:50%;border:0;padding:0;display:grid;place-items:center;cursor:pointer;background:color-mix(in srgb,var(--acc,var(--blue)) 12%,transparent);color:var(--acc,var(--blue));transition:background .2s,color .2s,transform .12s;-webkit-touch-callout:none;user-select:none}' +
    '.bcv-mic svg{width:22px;height:22px}.bcv-mic:active{transform:scale(.94)}.bcv-mic:disabled{opacity:.5}' +
    '.bcv-mic.rec{background:var(--red,#FF3B30);color:#fff;animation:bcvPulse 1.6s infinite}' +
    '@keyframes bcvPulse{0%{box-shadow:0 0 0 0 rgba(255,59,48,.45)}70%{box-shadow:0 0 0 12px rgba(255,59,48,0)}100%{box-shadow:0 0 0 0 rgba(255,59,48,0)}}' +
    '@media (prefers-reduced-motion:reduce){.bcv-mic.rec{animation:none}}' +
    '.bcv-bar{display:none;flex-wrap:wrap;align-items:center;gap:8px 10px;margin:8px 0 2px;padding:10px 12px;border-radius:12px;background:var(--bg);font:500 13.5px/1.3 -apple-system,system-ui,sans-serif;color:var(--text)}' +
    '.bcv-bar.on{display:flex}' +
    '.bcv-dot{width:8px;height:8px;border-radius:50%;background:var(--red,#FF3B30);flex-shrink:0}.bcv-bar.idle .bcv-dot{background:var(--text2)}' +
    '.bcv-t{font-variant-numeric:tabular-nums;font-weight:600;min-width:40px}' +
    '.bcv-lv{flex:0 0 64px;height:6px;border-radius:3px;background:color-mix(in srgb,var(--text2) 25%,transparent);overflow:hidden}.bcv-lv i{display:block;height:100%;width:0;background:var(--green,#34C759);border-radius:3px;transition:width .08s}.bcv-lv i.hot{background:var(--orange,#FF9500)}.bcv-bar.idle .bcv-lv{display:none}' +
    '.bcv-st{flex:1 1 110px;min-width:0;color:var(--text2)}.bcv-st.err{color:var(--red,#FF3B30)}' +
    '.bcv-bar button{border:0;border-radius:9px;padding:7px 11px;font:600 13px -apple-system,system-ui,sans-serif;cursor:pointer;background:var(--card);color:var(--text);flex-shrink:0}' +
    '.bcv-bar .bcv-stop{background:var(--red,#FF3B30);color:#fff}' +
    '.bcv-bar .bcv-gear{background:none;padding:4px 2px;color:var(--text2);font-size:16px}' +
    '.bcv-chips{display:flex;flex-wrap:wrap;gap:6px;width:100%}.bcv-chips button{padding:5px 10px;border-radius:999px;background:var(--card);font-weight:600;font-size:12.5px}.bcv-chips button.on{background:var(--acc,var(--blue));color:var(--on-acc,#fff)}' +
    '#bcvSheet{position:fixed;inset:0;z-index:9500;background:rgba(0,0,0,.45);display:none;align-items:flex-end;justify-content:center}#bcvSheet.open{display:flex}' +
    '#bcvSheet .sh{background:var(--card);color:var(--text);width:100%;max-width:520px;border-radius:22px 22px 0 0;padding:18px 18px calc(22px + env(safe-area-inset-bottom));max-height:88vh;overflow:auto;font:15px/1.4 -apple-system,system-ui,sans-serif}' +
    '#bcvSheet .hd{display:flex;align-items:center;margin-bottom:6px}#bcvSheet .hd b{flex:1;font-size:19px}#bcvSheet .hd button{border:0;width:34px;height:34px;border-radius:50%;background:var(--bg);color:var(--text);font-size:17px;cursor:pointer}' +
    '#bcvSheet h4{font-size:13px;font-weight:600;color:var(--text2);margin:14px 0 7px}' +
    '#bcvSheet .seg{display:flex;flex-wrap:wrap;gap:3px;background:var(--bg);padding:3px;border-radius:11px}#bcvSheet .seg button{flex:1 0 auto;border:0;border-radius:9px;padding:9px 8px;background:transparent;color:var(--text);font:600 13.5px -apple-system,system-ui,sans-serif;cursor:pointer}' +
    '#bcvSheet .seg button.on{background:var(--card);color:var(--acc,var(--blue));box-shadow:0 1px 3px rgba(0,0,0,.14)}' +
    '#bcvSheet input,#bcvSheet textarea{width:100%;margin:0;padding:12px 14px;border-radius:12px;border:0;background:var(--bg);color:var(--text);font:15px/1.4 -apple-system,system-ui,sans-serif;box-sizing:border-box}#bcvSheet textarea{min-height:64px;resize:vertical}' +
    '#bcvSheet .row{display:flex;align-items:center;gap:12px;margin-top:14px}#bcvSheet .row span{flex:1}#bcvSheet .row small{display:block;color:var(--text2);font-size:12.5px}' +
    '#bcvSheet .sw{position:relative;width:51px;height:31px;flex-shrink:0}#bcvSheet .sw input{opacity:0;width:0;height:0;position:absolute}#bcvSheet .sw i{position:absolute;inset:0;border-radius:31px;background:color-mix(in srgb,var(--text2) 35%,transparent);transition:background .2s}' +
    '#bcvSheet .sw i::after{content:"";position:absolute;left:2px;top:2px;width:27px;height:27px;border-radius:50%;background:#fff;box-shadow:0 2px 4px rgba(0,0,0,.2);transition:transform .2s}#bcvSheet .sw input:checked+i{background:var(--green,#34C759)}#bcvSheet .sw input:checked+i::after{transform:translateX(20px)}' +
    '#bcvSheet .mut{font-size:12.5px;color:var(--text2);margin-top:6px;line-height:1.45}' +
    '#bcvSheet .ok{width:100%;margin-top:18px;padding:14px;border:0;border-radius:14px;background:var(--acc,var(--blue));color:var(--on-acc,#fff);font:600 16px -apple-system,system-ui,sans-serif;cursor:pointer}';
  document.head.appendChild(css);

  /* ---------- окно настроек (как раздел «Движок» в Диктовщике) ---------- */
  function settings(onDone) {
    var c = cfg(), sh = document.getElementById('bcvSheet');
    if (!sh) { sh = document.createElement('div'); sh.id = 'bcvSheet'; document.body.appendChild(sh); sh.addEventListener('click', function (e) { if (e.target === sh) close(); }); }
    function seg(id, list, val) { return '<div class="seg" id="' + id + '">' + list.map(function (o) { return '<button data-v="' + o[0] + '" class="' + (o[0] === val ? 'on' : '') + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
    function render() {
      var g = c.engine === 'groq';
      sh.innerHTML = '<div class="sh"><div class="hd"><b>🎙 Голосовой ввод</b><button data-x aria-label="Закрыть">✕</button></div>' +
        '<div class="mut">Тот же механизм, что в «Диктовщике»: запись целиком, Whisper, голосовая пунктуация, ИИ-коррекция.</div>' +
        '<h4>Движок</h4>' + seg('bcvEng', [['openai', '🤖 OpenAI · Whisper'], ['groq', '⚡ Groq · быстрее']], c.engine) +
        '<h4>' + (g ? 'API-ключ Groq' : 'API-ключ OpenAI') + '</h4><input type="password" id="bcvKey" autocomplete="off" placeholder="' + (g ? 'gsk_…' : 'sk-…') + '" value="' + esc(keyFor(c.engine)) + '">' +
        '<div class="mut">' + (g ? 'Ключ на console.groq.com → API Keys (есть бесплатный лимит). Можно взять тот же, что в Диктовщике.' : 'Общий ключ с озвучкой книг; можно взять тот же, что в Диктовщике. Хранится только в этом телефоне.') + '</div>' +
        '<h4>Язык речи</h4>' + seg('bcvLang', LANGS, c.lang) +
        '<h4>Контекст для точности</h4><textarea id="bcvCtx" placeholder="Например: имена, термины, которые часто встречаются в моих отзывах…">' + esc(c.ctx) + '</textarea>' +
        '<div class="mut">Название, автор и режиссёр открытой карточки добавляются в контекст автоматически — имена распознаются точнее.</div>' +
        '<label class="row"><span>ИИ-коррекция<small>Исправляет пунктуацию, регистр и ошибки распознавания, не меняя смысл</small></span><span class="sw"><input type="checkbox" id="bcvCor"' + (c.correct ? ' checked' : '') + '><i></i></span></label>' +
        '<div class="mut" style="margin-top:12px">Голосовые команды: «запятая», «точка», «двоеточие», «тире», «вопросительный знак», «восклицательный знак», «три точки», «новая строка», «новый абзац», «открыть / закрыть кавычки».</div>' +
        '<button class="ok" data-x>Готово</button></div>';
      sh.querySelectorAll('[data-x]').forEach(function (b) { b.onclick = close; });
      sh.querySelector('#bcvEng').onclick = function (e) { var b = e.target.closest('button[data-v]'); if (!b) return; keep(); c.engine = b.dataset.v; saveCfg(c); render(); };
      sh.querySelector('#bcvLang').onclick = function (e) { var b = e.target.closest('button[data-v]'); if (!b) return; keep(); c.lang = b.dataset.v; saveCfg(c); render(); };
    }
    function keep() {
      var i = sh.querySelector('#bcvKey'); if (i) ls(c.engine === 'groq' ? GROQ : OAI, i.value.trim());
      var t = sh.querySelector('#bcvCtx'); if (t) c.ctx = t.value.trim();
      var s = sh.querySelector('#bcvCor'); if (s) c.correct = s.checked;
    }
    function close() { keep(); saveCfg(c); sh.classList.remove('open'); if (onDone) { var f = onDone; onDone = null; f(); } }
    sh.__close = close;
    render(); sh.classList.add('open');
  }

  /* ---------- одна диктовка ---------- */
  var active = null;
  function Session(field, btn, bar, ctxFn) {
    this.field = field; this.btn = btn; this.bar = bar; this.ctxFn = ctxFn;
    this.queue = []; this.failed = []; this.busy = false; this.stopped = false; this.got = '';
  }
  Session.prototype.ui = function (status, isErr) {
    var b = this.bar, live = !this.stopped;
    b.classList.add('on'); b.classList.toggle('idle', !live);
    var st = b.querySelector('.bcv-st'); st.textContent = status || ''; st.classList.toggle('err', !!isErr);
    b.querySelector('.bcv-retry').style.display = this.failed.length && !this.busy ? '' : 'none';
    b.querySelector('.bcv-stop').style.display = live ? '' : 'none';
    b.querySelector('.bcv-close').style.display = !live && !this.busy ? '' : 'none';
    var c = cfg();
    b.querySelector('.bcv-chips').innerHTML = live ? LANGS.slice(0, 3).map(function (l) { return '<button type="button" data-l="' + l[0] + '" class="' + (c.lang === l[0] ? 'on' : '') + '">' + l[1] + '</button>'; }).join('') : '';
  };
  Session.prototype.start = function () {
    var self = this;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { this.stopped = true; this.ui('Запись звука на этом устройстве недоступна', true); return; }
    this.ui('Включаю микрофон…');
    navigator.mediaDevices.getUserMedia({ audio: { sampleRate: { ideal: 48000 }, channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } }).then(function (stream) {
      if (self.stopped) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
      self.stream = stream; self.t0 = Date.now();
      self.mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].filter(function (m) { return MediaRecorder.isTypeSupported(m); })[0] || '';
      try {
        var AC = window.AudioContext || window.webkitAudioContext; self.ac = new AC();
        var src = self.ac.createMediaStreamSource(stream); self.an = self.ac.createAnalyser(); self.an.fftSize = 512; src.connect(self.an);
        self.data = new Uint8Array(self.an.frequencyBinCount);
      } catch (e) { self.an = null; }
      self.btn.classList.add('rec'); self.btn.innerHTML = STOP; self.btn.setAttribute('aria-label', 'Остановить запись');
      buzz(15);
      self.record();
      self.tick();
      self.ui('Запись… говорите, текст появится после «Стоп»');
    }).catch(function (e) {
      self.stopped = true; self.reset();
      self.ui(/NotAllowed|Permission|denied/i.test(String(e && (e.name || e.message))) ? 'Нет доступа к микрофону — разрешите его для BC в настройках телефона' : 'Микрофон не включился: ' + (e && e.message || e), true);
    });
  };
  Session.prototype.record = function () {
    var self = this, parts = [], opts = {};
    if (this.mime) { opts.mimeType = this.mime; if (this.mime.indexOf('webm') !== -1) opts.audioBitsPerSecond = 128000; }
    var rec = new MediaRecorder(this.stream, opts);
    rec.ondataavailable = function (e) { if (e.data && e.data.size > 0) parts.push(e.data); };
    rec.onstop = function () {
      var blob = new Blob(parts, { type: rec.mimeType || self.mime || 'audio/webm' });
      if (blob.size > 0) self.queue.push(blob);
      self.pump();
    };
    rec.start(1000);
    rec.__t = Date.now();
    this.rec = rec;
  };
  Session.prototype.tick = function () {
    var self = this; if (this.stopped) return;
    var now = Date.now(), sec = Math.floor((now - this.t0) / 1000);
    this.bar.querySelector('.bcv-t').textContent = ('0' + Math.floor(sec / 60)).slice(-2) + ':' + ('0' + sec % 60).slice(-2);
    if (this.an) {
      this.an.getByteFrequencyData(this.data);
      var s = 0; for (var i = 0; i < this.data.length; i++) s += this.data[i];
      var pct = Math.min(100, Math.round((s / this.data.length / 130) * 100));
      var lv = this.bar.querySelector('.bcv-lv i'); lv.style.width = pct + '%'; lv.classList.toggle('hot', pct > 85);
    }
    // очень длинная диктовка — продолжаем вторым файлом (лимит API 25 МБ)
    if (this.rec && now - this.rec.__t > SEG_MS) { var old = this.rec; this.record(); old.stop(); }
    this.raf = setTimeout(function () { self.tick(); }, 80);
  };
  Session.prototype.insert = function (txt) {
    if (!txt) return;
    var f = this.field, v = f.value, sep = v.length && !/[ \n]$/.test(v) ? ' ' : '';
    f.value = v + sep + txt;
    this.got += (this.got ? ' ' : '') + txt;
    try { f.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
    f.scrollTop = f.scrollHeight;
  };
  Session.prototype.context = function () {
    var a = [], c = cfg(), auto = '';
    try { auto = this.ctxFn ? (this.ctxFn() || '') : ''; } catch (e) {}
    if (auto) a.push(auto);
    if (c.ctx) a.push(c.ctx);
    return a.join('. ');
  };
  Session.prototype.pump = function () {
    var self = this;
    if (this.busy) return;
    var blob = this.queue.shift();
    if (!blob) { this.finish(); return; }
    this.busy = true;
    var c = cfg(), ctx = this.context();
    this.ui(this.stopped ? 'Распознаю…' : 'Запись идёт · распознаю предыдущую часть…');
    this.btn.disabled = this.stopped;
    transcribe(blob, c, ctx).then(function (raw) {
      if (!raw) return '';
      var t = processText(raw, c.lang);
      if (!c.correct) return t;
      self.ui('ИИ-коррекция…');
      return aiCorrect(t, c, ctx);
    }).then(function (t) { if (t) self.insert(t); }, function (e) { self.failed.push(blob); self.err = e.message || String(e); })
      .then(function () {
        self.busy = false; self.btn.disabled = false;
        if (self.err && !self.queue.length) { var m = self.err; self.err = ''; self.ui(m + ' · запись сохранена, можно повторить', true); if (self.stopped) { if (active === self) active = null; return; } }
        self.pump();
      });
  };
  Session.prototype.finish = function () {
    if (!this.stopped) { this.ui('Запись… говорите, текст появится после «Стоп»'); return; }
    if (this.failed.length) { this.ui('Не распознано: ' + this.err, true); }
    else {
      this.ui(this.got ? 'Готово ✓' : 'Ничего не распознано');
      var b = this.bar, me = this;
      setTimeout(function () { if (active !== me && !me.busy && !me.failed.length) b.classList.remove('on'); }, 2000);
    }
    if (active === this) active = null;
  };
  Session.prototype.stop = function () {
    if (this.stopped) return; this.stopped = true; clearTimeout(this.raf); buzz(10);
    var rec = this.rec;
    if (rec && rec.state !== 'inactive') rec.stop(); else this.pump();
    this.reset();
    this.ui('Распознаю…');
  };
  Session.prototype.reset = function () {
    try { this.stream && this.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { this.ac && this.ac.close(); } catch (e) {}
    this.btn.classList.remove('rec'); this.btn.innerHTML = MIC; this.btn.setAttribute('aria-label', 'Голосовой ввод');
  };
  Session.prototype.retry = function () { this.queue = this.failed.concat(this.queue); this.failed = []; active = this; this.pump(); };

  /* ---------- кнопка у поля ---------- */
  function attach(field, opts) {
    if (!field || field.__bcv) return; field.__bcv = true; opts = opts || {};
    var btn = document.createElement('button'); btn.type = 'button'; btn.className = 'bcv-mic'; btn.innerHTML = MIC; btn.setAttribute('aria-label', 'Голосовой ввод');
    field.parentNode.insertBefore(btn, field.nextSibling);
    var bar = document.createElement('div'); bar.className = 'bcv-bar';
    bar.innerHTML = '<span class="bcv-dot"></span><span class="bcv-t">00:00</span><span class="bcv-lv"><i></i></span><span class="bcv-st"></span>' +
      '<button type="button" class="bcv-retry">Повторить</button><button type="button" class="bcv-stop">■ Стоп</button><button type="button" class="bcv-close" aria-label="Скрыть">✕</button><button type="button" class="bcv-gear" aria-label="Настройки голосового ввода">⚙</button>' +
      '<div class="bcv-chips"></div>';
    var row = field.parentNode; row.parentNode.insertBefore(bar, row.nextSibling);
    var sess = null;
    bar.querySelector('.bcv-stop').onclick = function () { if (sess) sess.stop(); };
    bar.querySelector('.bcv-retry').onclick = function () { if (sess) sess.retry(); };
    bar.querySelector('.bcv-close').onclick = function () { bar.classList.remove('on'); };
    bar.querySelector('.bcv-gear').onclick = function () { settings(); };
    bar.querySelector('.bcv-chips').onclick = function (e) {
      var b = e.target.closest('button[data-l]'); if (!b) return;
      var c = cfg(); c.lang = b.dataset.l; saveCfg(c);
      Array.prototype.forEach.call(this.children, function (x) { x.classList.toggle('on', x === b); });
    };
    var lp = null, longFired = false;
    btn.addEventListener('pointerdown', function () { longFired = false; lp = setTimeout(function () { longFired = true; buzz(20); settings(); }, 600); });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) { btn.addEventListener(ev, function () { clearTimeout(lp); }); });
    btn.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      if (longFired) { longFired = false; return; }
      if (sess && !sess.stopped) { sess.stop(); return; }
      if (active && !active.stopped) active.stop();
      var go = function () { sess = new Session(field, btn, bar, opts.context); active = sess; sess.start(); };
      if (!keyFor(cfg().engine)) { settings(function () { if (keyFor(cfg().engine)) go(); }); return; }
      go();
    });
  }
  function stopAll() { if (active && !active.stopped) active.stop(); }
  function busy() { return !!(active && (!active.stopped || active.busy || active.queue.length)); }
  function whenIdle(fn) { stopAll(); var t0 = Date.now(); (function wait() { if (busy() && Date.now() - t0 < 60000) setTimeout(wait, 200); else fn(); })(); }

  function wrapBack() {
    var orig = window.androidBack;
    window.androidBack = function () {
      var sh = document.getElementById('bcvSheet'); if (sh && sh.classList.contains('open')) { sh.__close(); return true; }
      if (active && !active.stopped) { active.stop(); return true; }
      return orig ? orig() : false;
    };
  }
  if (document.readyState === 'complete') wrapBack(); else window.addEventListener('load', wrapBack);

  // перенести ключ Groq из старых настроек BC-5/6, если он там был
  try { var old = JSON.parse(ls('bc_voice') || '{}'); if (old.lang && !ls(SET)) saveCfg({ engine: old.engine || '', lang: old.lang || 'ru', ctx: '', correct: true }); } catch (e) {}

  window.BCVoice = { attach: attach, settings: function () { settings(); }, stopAll: stopAll, busy: busy, whenIdle: whenIdle, processText: processText };
})();
