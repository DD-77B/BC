/* BC: голосовой ввод в поля комментариев — механизм как в «Диктовщике».
   Запись идёт кусками: кусок отрезается на паузе в речи (после 15 с, не позже 28 с), каждый кусок сразу
   расшифровывается (OpenAI или Groq), текст дописывается в поле по мере диктовки. Хвост уже распознанного
   текста передаётся как подсказка — фразы на стыках кусков не рвутся. Неудачный кусок не теряется:
   его можно отправить повторно.
   BCVoice.attach(textarea, { place: 'after' | 'before', anchor: element }) — добавить кнопку микрофона.
   BCVoice.settings() — окно настроек (движок, ключи, модель, язык). Долгое нажатие на микрофон — то же окно. */
(function () {
  if (window.BCVoice) return;
  var SET = 'bc_voice', GROQ = 'bc_groq_key', OAI = 'books_openai_api_key';
  var MIN_CHUNK = 15000, MAX_CHUNK = 28000, QUIET_MS = 450;
  var MODELS = {
    openai: [['gpt-4o-transcribe', 'Точнее'], ['gpt-4o-mini-transcribe', 'Дешевле'], ['whisper-1', 'Whisper']],
    groq: [['whisper-large-v3-turbo', 'Быстро'], ['whisper-large-v3', 'Точнее']]
  };
  var LANGS = [['ru', 'Русский'], ['en', 'English'], ['es', 'Español'], ['', 'Авто']];
  var MIC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/></svg>';
  var STOP = '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2.2" fill="currentColor"/></svg>';

  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k) || ''; if (v) localStorage.setItem(k, v); else localStorage.removeItem(k); } catch (e) { return ''; } }
  function cfg() { var d = { engine: '', model: '', lang: 'ru' }; try { var s = JSON.parse(ls(SET) || '{}'); for (var k in s) d[k] = s[k]; } catch (e) {} if (!d.engine) d.engine = ls(OAI) ? 'openai' : (ls(GROQ) ? 'groq' : 'openai'); if (!MODELS[d.engine].some(function (m) { return m[0] === d.model; })) d.model = MODELS[d.engine][0][0]; return d; }
  function saveCfg(c) { ls(SET, JSON.stringify(c)); }
  function keyFor(engine) { return ls(engine === 'groq' ? GROQ : OAI); }
  function esc(t) { return String(t || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function buzz(ms) { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} }

  var css = document.createElement('style');
  css.textContent =
    '.bcv-wrap{position:relative}' +
    '.bcv-mic{flex-shrink:0;width:44px;height:44px;border-radius:50%;border:0;padding:0;display:grid;place-items:center;cursor:pointer;background:color-mix(in srgb,var(--acc,var(--blue)) 12%,transparent);color:var(--acc,var(--blue));transition:background .2s,color .2s,transform .12s;-webkit-touch-callout:none;user-select:none}' +
    '.bcv-mic svg{width:22px;height:22px}.bcv-mic:active{transform:scale(.94)}' +
    '.bcv-mic.rec{background:var(--red,#FF3B30);color:#fff;box-shadow:0 0 0 0 rgba(255,59,48,.45);animation:bcvPulse 1.6s infinite}' +
    '@keyframes bcvPulse{0%{box-shadow:0 0 0 0 rgba(255,59,48,.45)}70%{box-shadow:0 0 0 12px rgba(255,59,48,0)}100%{box-shadow:0 0 0 0 rgba(255,59,48,0)}}' +
    '@media (prefers-reduced-motion:reduce){.bcv-mic.rec{animation:none}}' +
    '.bcv-bar{display:none;flex-wrap:wrap;align-items:center;gap:8px 10px;margin:8px 0 2px;padding:9px 12px;border-radius:12px;background:var(--bg);font:500 13.5px/1.3 -apple-system,system-ui,sans-serif;color:var(--text)}' +
    '.bcv-bar.on{display:flex}' +
    '.bcv-dot{width:8px;height:8px;border-radius:50%;background:var(--red,#FF3B30);flex-shrink:0}.bcv-bar.idle .bcv-dot{background:var(--text2)}' +
    '.bcv-t{font-variant-numeric:tabular-nums;font-weight:600;min-width:38px}' +
    '.bcv-lv{display:flex;align-items:center;gap:2px;height:18px}.bcv-lv i{width:3px;border-radius:2px;background:var(--red,#FF3B30);height:3px;transition:height .08s}.bcv-bar.idle .bcv-lv{display:none}' +
    '.bcv-st{flex:1 1 110px;min-width:0;color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bcv-st.err{color:var(--red,#FF3B30);white-space:normal}' +
    '.bcv-bar button{border:0;border-radius:9px;padding:7px 10px;font:600 13px -apple-system,system-ui,sans-serif;cursor:pointer;background:var(--card);color:var(--text);flex-shrink:0}' +
    '.bcv-bar .bcv-gear{background:none;padding:4px;color:var(--text2);font-size:16px}' +
    '#bcvSheet{position:fixed;inset:0;z-index:9500;background:rgba(0,0,0,.45);display:none;align-items:flex-end;justify-content:center}#bcvSheet.open{display:flex}' +
    '#bcvSheet .sh{background:var(--card);color:var(--text);width:100%;max-width:520px;border-radius:22px 22px 0 0;padding:18px 18px calc(22px + env(safe-area-inset-bottom));max-height:88vh;overflow:auto;font:15px/1.4 -apple-system,system-ui,sans-serif}' +
    '#bcvSheet .hd{display:flex;align-items:center;margin-bottom:12px}#bcvSheet .hd b{flex:1;font-size:19px}#bcvSheet .hd button{border:0;width:34px;height:34px;border-radius:50%;background:var(--bg);color:var(--text);font-size:17px;cursor:pointer}' +
    '#bcvSheet h4{font-size:13px;font-weight:600;color:var(--text2);margin:14px 0 7px}' +
    '#bcvSheet .seg{display:flex;gap:3px;background:var(--bg);padding:3px;border-radius:11px}#bcvSheet .seg button{flex:1;border:0;border-radius:9px;padding:9px 4px;background:transparent;color:var(--text);font:600 13.5px -apple-system,system-ui,sans-serif;cursor:pointer}' +
    '#bcvSheet .seg button.on{background:var(--card);color:var(--acc,var(--blue));box-shadow:0 1px 3px rgba(0,0,0,.12)}' +
    '#bcvSheet input{width:100%;margin:0;padding:12px 14px;border-radius:12px;border:0;background:var(--bg);color:var(--text);font-size:15px}' +
    '#bcvSheet .mut{font-size:12.5px;color:var(--text2);margin-top:6px;line-height:1.4}' +
    '#bcvSheet .ok{width:100%;margin-top:16px;padding:14px;border:0;border-radius:14px;background:var(--acc,var(--blue));color:#fff;font:600 16px -apple-system,system-ui,sans-serif;cursor:pointer}';
  document.head.appendChild(css);

  /* ---------- окно настроек ---------- */
  function settings(onDone) {
    var c = cfg(), sh = document.getElementById('bcvSheet');
    if (!sh) { sh = document.createElement('div'); sh.id = 'bcvSheet'; document.body.appendChild(sh); sh.addEventListener('click', function (e) { if (e.target === sh) close(); }); }
    function seg(id, list, val) { return '<div class="seg" id="' + id + '">' + list.map(function (o) { return '<button data-v="' + o[0] + '" class="' + (o[0] === val ? 'on' : '') + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
    function render() {
      sh.innerHTML = '<div class="sh"><div class="hd"><b>Голосовой ввод</b><button data-x>✕</button></div>' +
        '<h4>Распознавание</h4>' + seg('bcvEng', [['openai', 'OpenAI'], ['groq', 'Groq']], c.engine) +
        '<h4>' + (c.engine === 'groq' ? 'Ключ Groq' : 'Ключ OpenAI') + '</h4><input type="password" id="bcvKey" autocomplete="off" placeholder="' + (c.engine === 'groq' ? 'gsk_…' : 'sk-…') + '" value="' + esc(keyFor(c.engine)) + '">' +
        '<div class="mut">' + (c.engine === 'groq' ? 'Ключ на console.groq.com → API Keys. Groq распознаёт очень быстро и почти бесплатно.' : 'Тот же ключ, что и для озвучки книг. Хранится только в этом телефоне.') + '</div>' +
        '<h4>Модель</h4>' + seg('bcvMod', MODELS[c.engine], c.model) +
        '<h4>Язык речи</h4>' + seg('bcvLang', LANGS, c.lang) +
        '<div class="mut">Запись нарезается на куски по паузам в речи; каждый кусок расшифровывается сразу, поэтому длинная диктовка появляется в поле по частям.</div>' +
        '<button class="ok" data-x>Готово</button></div>';
      sh.querySelectorAll('[data-x]').forEach(function (b) { b.onclick = close; });
      [['bcvEng', 'engine'], ['bcvMod', 'model'], ['bcvLang', 'lang']].forEach(function (p) {
        sh.querySelector('#' + p[0]).onclick = function (e) {
          var b = e.target.closest('button[data-v]'); if (!b) return;
          keep(); c[p[1]] = b.dataset.v; if (p[1] === 'engine') c.model = MODELS[c.engine][0][0]; saveCfg(c); render();
        };
      });
    }
    function keep() { var i = sh.querySelector('#bcvKey'); if (i) ls(c.engine === 'groq' ? GROQ : OAI, i.value.trim()); }
    function close() { keep(); saveCfg(c); sh.classList.remove('open'); if (onDone) { var f = onDone; onDone = null; f(); } }
    sh.__close = close;
    render(); sh.classList.add('open');
  }

  /* ---------- расшифровка куска ---------- */
  function transcribe(blob, prompt) {
    var c = cfg(), key = keyFor(c.engine);
    if (!key) return Promise.reject(new Error('Нет ключа ' + (c.engine === 'groq' ? 'Groq' : 'OpenAI')));
    var ext = /mp4|m4a|aac/.test(blob.type) ? 'm4a' : /ogg/.test(blob.type) ? 'ogg' : 'webm';
    var fd = new FormData();
    fd.append('file', blob, 'chunk.' + ext);
    fd.append('model', c.model);
    if (c.lang) fd.append('language', c.lang);
    if (prompt) fd.append('prompt', prompt.slice(-220));
    fd.append('response_format', c.model.indexOf('gpt-4o') === 0 ? 'json' : 'json');
    if (c.model.indexOf('gpt-4o') !== 0) fd.append('temperature', '0');
    var url = c.engine === 'groq' ? 'https://api.groq.com/openai/v1/audio/transcriptions' : 'https://api.openai.com/v1/audio/transcriptions';
    return fetch(url, { method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: fd }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) {
          var m = (j && j.error && (j.error.message || j.error)) || ('ошибка ' + r.status);
          if (r.status === 401) m = 'Неверный ключ ' + (c.engine === 'groq' ? 'Groq' : 'OpenAI');
          else if (r.status === 429) m = 'Лимит запросов, попробуйте через минуту';
          throw new Error(m);
        }
        return String((j && j.text) || '').trim();
      });
    });
  }

  /* ---------- одна сессия записи на одно поле ---------- */
  var active = null;
  function Session(field, btn, bar) {
    this.field = field; this.btn = btn; this.bar = bar; this.queue = []; this.failed = []; this.busy = false; this.stopped = false; this.textSoFar = '';
  }
  Session.prototype.ui = function (status, isErr) {
    var b = this.bar, live = !this.stopped;
    b.classList.add('on'); b.classList.toggle('idle', !live);
    var st = b.querySelector('.bcv-st'); st.textContent = status || ''; st.classList.toggle('err', !!isErr);
    b.querySelector('.bcv-retry').style.display = this.failed.length && !this.busy ? '' : 'none';
    b.querySelector('.bcv-stop').style.display = live ? '' : 'none';
    b.querySelector('.bcv-close').style.display = !live && !this.busy ? '' : 'none';
  };
  Session.prototype.start = function () {
    var self = this;
    var mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'].filter(function (m) { return window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(m); })[0] || '';
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { this.stopped = true; this.ui('Запись звука на этом устройстве недоступна', true); return; }
    this.ui('Включаю микрофон…');
    navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }).then(function (stream) {
      if (self.stopped) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
      self.stream = stream; self.mime = mime; self.t0 = Date.now();
      try {
        var AC = window.AudioContext || window.webkitAudioContext; self.ac = new AC();
        var src = self.ac.createMediaStreamSource(stream); self.an = self.ac.createAnalyser(); self.an.fftSize = 1024; src.connect(self.an);
        self.buf = new Float32Array(self.an.fftSize);
      } catch (e) { self.an = null; }
      self.btn.classList.add('rec'); self.btn.innerHTML = STOP; self.btn.setAttribute('aria-label', 'Остановить запись');
      buzz(15);
      self.newRecorder();
      self.tick();
      self.ui('Говорите — текст появится по частям');
    }).catch(function (e) {
      self.stopped = true; self.reset();
      self.ui(/Permission|NotAllowed|denied/i.test(String(e && (e.name || e.message))) ? 'Нет доступа к микрофону — разрешите его для BC в настройках телефона' : 'Микрофон не включился: ' + (e && e.message || e), true);
    });
  };
  Session.prototype.newRecorder = function () {
    var self = this, parts = [];
    var rec = this.mime ? new MediaRecorder(this.stream, { mimeType: this.mime, audioBitsPerSecond: 48000 }) : new MediaRecorder(this.stream);
    rec.ondataavailable = function (e) { if (e.data && e.data.size) parts.push(e.data); };
    rec.onstop = function () {
      var blob = new Blob(parts, { type: rec.mimeType || self.mime || 'audio/webm' });
      if (blob.size > 2500 && rec.__voiced) self.queue.push(blob);
      self.pump();
    };
    rec.__start = Date.now(); rec.__voiced = false;
    rec.start();
    this.rec = rec; this.quietSince = 0;
  };
  Session.prototype.cut = function () { var old = this.rec; if (!old || old.state === 'inactive') return; if (!this.stopped) this.newRecorder(); old.stop(); };
  Session.prototype.tick = function () {
    var self = this; if (this.stopped) return;
    var lvl = 0;
    if (this.an) { this.an.getFloatTimeDomainData(this.buf); var s = 0; for (var i = 0; i < this.buf.length; i++) s += this.buf[i] * this.buf[i]; lvl = Math.sqrt(s / this.buf.length); }
    var now = Date.now(), rec = this.rec, age = rec ? now - rec.__start : 0, loud = lvl > 0.018;
    if (rec && loud) rec.__voiced = true;
    if (!this.an && rec) rec.__voiced = true;
    if (loud) this.quietSince = 0; else if (!this.quietSince) this.quietSince = now;
    if (age > MAX_CHUNK || (age > MIN_CHUNK && this.quietSince && now - this.quietSince > QUIET_MS)) this.cut();
    var sec = Math.floor((now - this.t0) / 1000);
    this.bar.querySelector('.bcv-t').textContent = Math.floor(sec / 60) + ':' + ('0' + sec % 60).slice(-2);
    var bars = this.bar.querySelectorAll('.bcv-lv i'), h = Math.min(1, lvl * 9);
    for (var j = 0; j < bars.length; j++) bars[j].style.height = Math.max(3, Math.round(18 * h * (0.55 + 0.45 * Math.abs(Math.sin(now / 130 + j * 1.3))))) + 'px';
    this.raf = setTimeout(function () { self.tick(); }, 70);
  };
  Session.prototype.insert = function (txt) {
    if (!txt) return;
    var f = this.field, v = f.value, sep = v && !/\s$/.test(v) ? ' ' : '';
    f.value = v + sep + txt;
    this.textSoFar += (this.textSoFar ? ' ' : '') + txt;
    try { f.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
    f.scrollTop = f.scrollHeight;
  };
  Session.prototype.pump = function () {
    var self = this;
    if (this.busy) return;
    var blob = this.queue.shift();
    if (!blob) { this.finishIfDone(); return; }
    this.busy = true;
    this.ui(this.stopped ? 'Расшифровываю…' : 'Говорите — расшифровываю предыдущую часть…');
    var ctx = (this.field.value || '').slice(-220);
    transcribe(blob, ctx).then(function (t) { self.insert(t); }, function (e) { self.failed.push(blob); self.lastErr = e.message || String(e); })
      .then(function () { self.busy = false; if (self.lastErr && !self.queue.length) { self.ui(self.lastErr + (self.failed.length ? ' · кусков не расшифровано: ' + self.failed.length : ''), true); self.lastErr = ''; if (self.stopped) return; } self.pump(); });
  };
  Session.prototype.finishIfDone = function () {
    if (!this.stopped || this.busy || this.queue.length) { if (!this.stopped) this.ui('Говорите — текст появится по частям'); return; }
    if (this.failed.length) this.ui('Не расшифровано кусков: ' + this.failed.length, true);
    else { this.ui(this.textSoFar ? 'Готово' : 'Речь не распознана'); var b = this.bar, me = this; setTimeout(function () { if (active !== me && !me.busy && !me.failed.length) b.classList.remove('on'); }, 1800); }
    if (active === this) active = null;
  };
  Session.prototype.stop = function () {
    if (this.stopped) return; this.stopped = true; clearTimeout(this.raf); buzz(10);
    var rec = this.rec; if (rec && rec.state !== 'inactive') rec.stop(); else this.pump();
    this.reset();
    this.ui('Расшифровываю…');
  };
  Session.prototype.reset = function () {
    try { this.stream && this.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { this.ac && this.ac.close(); } catch (e) {}
    this.btn.classList.remove('rec'); this.btn.innerHTML = MIC; this.btn.setAttribute('aria-label', 'Голосовой ввод');
  };
  Session.prototype.retry = function () { this.queue = this.failed.concat(this.queue); this.failed = []; if (this.stopped && active !== this) active = this; this.pump(); };

  /* ---------- кнопка у поля ---------- */
  function attach(field, opts) {
    if (!field || field.__bcv) return; field.__bcv = true; opts = opts || {};
    var btn = document.createElement('button'); btn.type = 'button'; btn.className = 'bcv-mic'; btn.innerHTML = MIC; btn.setAttribute('aria-label', 'Голосовой ввод');
    var anchor = opts.anchor || field;
    if (opts.place === 'before') anchor.parentNode.insertBefore(btn, anchor); else anchor.parentNode.insertBefore(btn, anchor.nextSibling);
    var bar = document.createElement('div'); bar.className = 'bcv-bar';
    bar.innerHTML = '<span class="bcv-dot"></span><span class="bcv-t">0:00</span><span class="bcv-lv"><i></i><i></i><i></i><i></i><i></i></span><span class="bcv-st"></span>' +
      '<button type="button" class="bcv-retry">Повторить</button><button type="button" class="bcv-stop">Готово</button><button type="button" class="bcv-close">✕</button><button type="button" class="bcv-gear" aria-label="Настройки голосового ввода">⚙</button>';
    var row = opts.barAfter || field.parentNode; row.parentNode.insertBefore(bar, row.nextSibling);
    var sess = null;
    bar.querySelector('.bcv-stop').onclick = function () { if (sess) sess.stop(); };
    bar.querySelector('.bcv-retry').onclick = function () { if (sess) sess.retry(); };
    bar.querySelector('.bcv-close').onclick = function () { bar.classList.remove('on'); };
    bar.querySelector('.bcv-gear').onclick = function () { settings(); };
    var lp = null, longFired = false;
    btn.addEventListener('pointerdown', function () { longFired = false; lp = setTimeout(function () { longFired = true; buzz(20); settings(); }, 600); });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) { btn.addEventListener(ev, function () { clearTimeout(lp); }); });
    btn.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      if (longFired) { longFired = false; return; }
      if (sess && !sess.stopped) { sess.stop(); return; }
      if (active && !active.stopped) active.stop();
      var go = function () { sess = new Session(field, btn, bar); active = sess; sess.start(); };
      if (!keyFor(cfg().engine)) { settings(function () { if (keyFor(cfg().engine)) go(); }); return; }
      go();
    });
    field.__bcvStop = function () { if (sess && !sess.stopped) sess.stop(); };
  }
  function stopAll() { if (active && !active.stopped) active.stop(); }
  function busy() { return !!(active && (!active.stopped || active.busy || active.queue.length)); }
  // сохранить карточку только после того, как вся надиктовка попала в поле
  function whenIdle(fn) { stopAll(); var t0 = Date.now(); (function wait() { if (busy() && Date.now() - t0 < 30000) setTimeout(wait, 200); else fn(); })(); }

  // «Назад»: сначала закрыть окно настроек, потом остановить запись
  function wrapBack() {
    var orig = window.androidBack;
    window.androidBack = function () {
      var sh = document.getElementById('bcvSheet'); if (sh && sh.classList.contains('open')) { sh.__close(); return true; }
      if (active && !active.stopped) { active.stop(); return true; }
      return orig ? orig() : false;
    };
  }
  if (document.readyState === 'complete') wrapBack(); else window.addEventListener('load', wrapBack);
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') stopAll(); });

  window.BCVoice = { attach: attach, settings: function () { settings(); }, stopAll: stopAll, busy: busy, whenIdle: whenIdle, transcribe: transcribe };
})();
